declare module 'stream/web' {
    // stub module, pending copy&paste from .d.ts or manual impl
}
declare module 'node:stream/web' {
    export * from 'stream/web';
}
