# @firebase/auth-types

## 0.10.3

### Patch Changes

- [`3f370215a`](https://github.com/firebase/firebase-js-sdk/commit/3f370215aa571db6b41b92a7d8a9aaad2ea0ecd0) [#4808](https://github.com/firebase/firebase-js-sdk/pull/4808) (fixes [#4789](https://github.com/firebase/firebase-js-sdk/issues/4789)) - Update peerDependencies

## 0.10.2

### Patch Changes

- [`4ab5a9ce5`](https://github.com/firebase/firebase-js-sdk/commit/4ab5a9ce5b6256a95d745f6dc40a5e5ddd2301f2) [#4481](https://github.com/firebase/firebase-js-sdk/pull/4481) - Add emulator methods to auth-types.
