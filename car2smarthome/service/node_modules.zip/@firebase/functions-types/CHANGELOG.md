# @firebase/functions-types

## 0.4.0
### Minor Changes



- [`0322c1bda`](https://github.com/firebase/firebase-js-sdk/commit/0322c1bda93b2885b995e3df2b63b48314546961) [#3906](https://github.com/firebase/firebase-js-sdk/pull/3906)  - Add a useEmulator(host, port) method to Cloud Functions
