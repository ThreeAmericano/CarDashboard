var parent = require('../../es/array-buffer');

module.exports = parent;
