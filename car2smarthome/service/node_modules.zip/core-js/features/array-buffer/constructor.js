var parent = require('../../es/array-buffer/constructor');

module.exports = parent;
