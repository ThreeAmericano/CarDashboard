require('../../modules/esnext.array.is-template-object');
var path = require('../../internals/path');

module.exports = path.Array.isTemplateObject;
