var parent = require('../../../es/array/virtual/flat');

module.exports = parent;
