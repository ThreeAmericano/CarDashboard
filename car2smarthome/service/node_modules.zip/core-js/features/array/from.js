var parent = require('../../es/array/from');

module.exports = parent;
