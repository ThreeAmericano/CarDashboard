var parent = require('../../es/array/find');

module.exports = parent;
