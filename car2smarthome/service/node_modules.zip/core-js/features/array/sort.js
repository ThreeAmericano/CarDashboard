var parent = require('../../es/array/sort');

module.exports = parent;
