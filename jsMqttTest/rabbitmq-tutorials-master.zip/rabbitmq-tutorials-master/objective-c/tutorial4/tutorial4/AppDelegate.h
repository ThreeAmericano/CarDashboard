//
//  AppDelegate.h
//  tutorial4
//
//  Created by Pivotal on 25/04/2016.
//  Copyright © 2016 RabbitMQ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

